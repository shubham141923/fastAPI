import json 

apiKey = 'ajncjsfkjffkdsjkjkjvsndsjnvnsfjnscn'

def getDataAPI():
    a = 10
    c= 40
    b= 20
    sum = a +b
    return {'output':sum }

def postDataAPI(request_json):
    a = request_json['a']
    b= request_json['b']
    sum = a +b
    return {'output':sum}