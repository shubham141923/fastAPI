from fastapi import FastAPI, Request, APIRouter
from models.model import getDataAPI ,postDataAPI
abc = APIRouter()

@abc.get("/")
async def noroutes():
    return "Welcome to this API. No routes specified."

@abc.get("/getRequest")
async def getFunctionSUM():
    resutl = getDataAPI()
    return resutl

@abc.post("/Post")
async def getReq(request: Request):
    request_json = await request.json()
    result =  postDataAPI(request_json)
    return result

